# music/

Put your own royalty-free background-music files here (.mp3, .wav, .m4a, or .ogg).

Where to get free tracks:
- YouTube Studio -> Audio Library (safest - YouTube's own library, zero copyright-claim risk)
- https://pixabay.com/music/ (royalty-free, no attribution required)

The script picks a random track from this folder for each video and mixes it
under the voice at low volume. If this folder is empty, videos are produced
without background music - the pipeline never breaks because of a missing track.

This README is just a placeholder so the empty folder gets committed to git -
delete it once you've added real tracks (or leave it, it's harmless).
