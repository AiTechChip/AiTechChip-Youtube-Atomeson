# assets/

Put your channel logo here, named exactly: logo.png

Requirements:
- Must be a PNG with a TRANSPARENT background (export from Canva with
  "Transparent background" enabled) - otherwise the watermark shows a
  solid box instead of just the logo shape.

Used for:
- A small watermark in the top-right corner of every video
- A short (~0.8s) branded intro sting at the start of every video

If logo.png is missing, the script skips both features gracefully - the
pipeline never breaks because of a missing logo.

This README is just a placeholder so the empty folder gets committed to git -
delete it once you've added your real logo.png (or leave it, it's harmless).
